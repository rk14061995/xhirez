<section class="paduj5 backG">
   <div class="container py-5">
        <div class="row ">
            <div class="col-md-4">
                <div class="memberTitle">
                    <h2>Join our Premium Plans right now</h2>
                </div>
            </div>
            <div class="col-md-8">
                <div class="py-3">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                        when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </p>
                </div>
            </div>
        </div>
   </div>

   <div class="container py-5">
        <div class="row mx-0">
            <div class="col-md-4">
                 <div class="planss">
                     <div class="">
                        <div class="text-center margbot25">
                            <div class="pricePlan">
                                <span class=""><i class="fas fa-rupee-sign"></i> 60</span>
                            </div>
                        </div>
                        
                         <div class="text-center margbot25 line_h12">
                            <h4 class="mb-0">SILVER</h4>
                            <small>For 60 days</small>
                         </div>
                         <div class="text-center">
                            <ul class="planLista">
                                <li>
                                    <span><i class="fas fa-check-double"></i></span><small class="ml-2">Post 1 Job</small>
                                </li>
                                <li>
                                    <span><i class="fas fa-check-double"></i></span><small class="ml-2">5 Products</small>
                                </li>
                                <li>
                                    <span><i class="fas fa-check-double"></i></span><small class="ml-2">1 Assessment</small>
                                </li>
                                <li>
                                    <span><i class="fas fa-check-double"></i></span><small class="ml-2">1 Practice Test</small>
                                </li>
                                <li>
                                    <span><i class="fas fa-check-double"></i></span><small class="ml-2">Job Application</small>
                                </li>
                            </ul>
                         </div>
                         <div class="">
                             <button class="darkBtn w-100">
                                    Get Started
                             </button>
                         </div>
                     </div>
                 </div>   
            </div>
        </div>
   </div>
</section>