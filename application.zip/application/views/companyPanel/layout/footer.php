
<!-- 
<section class=" ">
     <hr>
  <div class="row mx-0">
      <div class="col-md-6">
          <div class="">
              <ul class="footLinks p-0 mt-3">
                  <li>
                      <a to="">Help Center</a>
                  </li>
                  <li>
                      <a to="">Fraud Alert</a>
                  </li>
                  <li>
                      <a to="">Terms & Conditions</a>
                  </li>
                 
              </ul>
          </div>
      </div>
      <div class="col-md-6">
          <div class="text_right">
              <ul class="footLinks p-0 d-block mb-0 colBrown">
                  <li>
                      <a to=""><span><i class="fas fa-phone-alt"></i></span> <span class="ml-2">080-47105555</span></a>
                  </li>
                  <li>
                      <a to=""><span><i class="far fa-envelope"></i></span> <span class="ml-2">recruiterservices@shine.com</span></a>
                  </li>
                  
              </ul>
              <span class="fnt_14 mr-4 ml-3">© 2020 </span>
          </div>
      </div>
  </div>
</section> -->